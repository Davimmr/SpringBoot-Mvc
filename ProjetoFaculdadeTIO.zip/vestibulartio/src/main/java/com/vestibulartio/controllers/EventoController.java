package com.vestibulartio.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import com.vestibulartio.models.Convidado;
import com.vestibulartio.models.Evento;
import com.vestibulartio.repository.ConvidadoRepository;
import com.vestibulartio.repository.EventoRepository;

@Controller
public class EventoController {

	@Autowired
	private EventoRepository er;
	
	@Autowired
	private ConvidadoRepository cr;
	
	@RequestMapping(value="/cadastrarEvento", method=RequestMethod.GET)
	public String form() {
		return "evento/formEvento";
	}
	
	@RequestMapping(value= "/cadastrarEvento", method=RequestMethod.POST)
	public ResponseEntity<?> form(Evento evento){
		er.save(evento);
		return ResponseEntity.status(HttpStatus.CREATED).body(evento);
	}
	
	@RequestMapping("/eventos")
	public ModelAndView listaEventos(){
		ModelAndView mv = new ModelAndView("listaevento");
		Iterable<Evento> eventos = er.findAll();
		mv.addObject("eventos", eventos);
		return mv;
	}
	
	@RequestMapping(value="/{codigo}", method=RequestMethod.GET)
	public ModelAndView detalhesEvento(@PathVariable("codigo") long codigo){
		Evento evento = er.findByCodigo(codigo);
		ModelAndView mv = new ModelAndView("evento/detalhesEventos");
		mv.addObject("evento", evento);
		
		Iterable<Convidado> convidado = cr.findByEvento(evento);
		mv.addObject("convidado", convidado);
		return mv;
	}
	
	@RequestMapping("/deletarEvento")
	public String deletarEvento(long codigo){
		Evento evento = er.findByCodigo(codigo);
		er.delete(evento);
		return "redirect:/eventos";
	}
	
	/*@RequestMapping(value = "/deletarEvento", method = RequestMethod.DELETE)
    public ResponseEntity<?> deletarEvento(@PathVariable("codigo") long codigo) {

        Evento evento = er.findByCodigo(codigo);
        er.delete(evento);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
    }
	
	/*
	@RequestMapping(value= {"/deletarEvento"}, method = RequestMethod.DELETE)
	public ResponseEntity<?> deletarEvento(@PathVariable("codigo") long idCodigo )
	{
		Evento evento = er.findByCodigo(idCodigo);
		er.delete(evento);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
	}	
	
	@RequestMapping(value= {"/deletarEvento"}, method = RequestMethod.DELETE)
	public ResponseEntity<?> deletarEvento(@PathVariable(value = "codigo") Long idCodigo) {
	    Evento evento = er.findByCodigo(idCodigo);
	    er.delete(evento);
	    return ResponseEntity.ok().build();
	}*/
	
	@RequestMapping(value="/{codigo}", method=RequestMethod.POST)
	public String detalhesEventoPost(@PathVariable("codigo") long codigo, @Valid Convidado convidado,  BindingResult result, RedirectAttributes attributes){
		if(result.hasErrors()){
			attributes.addFlashAttribute("mensagem", "Verifique os campos!");
			return "redirect:/{codigo}";
		}
		Evento evento = er.findByCodigo(codigo);
		convidado.setEvento(evento);
		cr.save(convidado);
		attributes.addFlashAttribute("mensagem", "Convidado adicionado com sucesso!");
		return "redirect:/{codigo}";
	}
	
	@RequestMapping("/deletarConvidado")
	public String deletarConvidado(long cpf){
		Convidado convidado = cr.findByCpf(cpf);
		cr.delete(convidado);
		
		Evento evento = convidado.getEvento();
		long codigoLong = evento.getCodigo();
		String codigo = "" + codigoLong;
		return "redirect:/" + codigo;
	}
	
}
