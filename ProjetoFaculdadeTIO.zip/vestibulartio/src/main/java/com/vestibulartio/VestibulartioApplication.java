package com.vestibulartio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VestibulartioApplication {

	public static void main(String[] args) {
		SpringApplication.run(VestibulartioApplication.class, args);
	}
}
